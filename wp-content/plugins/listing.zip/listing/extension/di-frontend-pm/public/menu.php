<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

?>

	  
<div id='difp-menu'>

	<?php //do_action('difp_menu_button'); ?>

</div><!--#difp-menu -->
<div id='difp-content'>
	  
	<?php //do_action('difp_display_before_content'); ?>

