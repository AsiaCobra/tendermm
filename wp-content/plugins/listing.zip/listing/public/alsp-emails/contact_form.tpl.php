<?php _e('Advert title:', 'ALSP'); ?> <?php echo $listing_title; ?>

<?php _e('Advert URL:', 'ALSP'); ?> <?php echo $listing_url; ?>

<?php _e('Name:', 'ALSP'); ?> <?php echo $name; ?>

<?php _e('Email:', 'ALSP'); ?> <?php echo $email; ?>

<?php _e('Message:', 'ALSP'); ?>


<?php echo $message; ?>