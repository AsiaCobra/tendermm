<?php global $ALSP_ADIMN_SETTINGS; ?>
<div class="alsp-content my-fav_wrap">	
	<?php alsp_renderTemplate('views/alsp_adverts_wrapper.tpl.php', array('public_control' => $public_control)); ?>
</div>