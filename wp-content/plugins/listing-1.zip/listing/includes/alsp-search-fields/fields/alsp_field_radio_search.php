<?php 

class alsp_content_field_radio_search extends alsp_content_field_select_search {

}
?>