<?php 

class alsp_content_field_textarea_search extends alsp_content_field_string_search {

}
?>