jQuery(document).ready(function() {

 jQuery('.pacz-select2').select2();

});