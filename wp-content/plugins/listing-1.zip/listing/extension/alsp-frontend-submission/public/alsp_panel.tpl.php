<?php alsp_renderMessages(); ?>
<div class="tab-pane active">
	<?php alsp_renderTemplate($public_control->subtemplate, array('public_control' => $public_control)); ?>
</div>

