<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

?>

		</div><!--#difp-content -->
	  
	<div id='difp-footer'>

	<?php do_action('difp_footer_note'); ?>

	</div><!--#difp-footer -->
</div><!--#difp-wrapper -->

