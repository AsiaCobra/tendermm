<div class="alsp-content meta-item">
	<input type="text" name="marker_color" class="marker_color" value="<?php echo esc_attr($color); ?>" />
	<input type="hidden" name="listingtype_id" class="listingtype_id" value="<?php echo esc_attr($term_id); ?>" />
	<input type="button" name="save_color" class="save_color button button-primary" value="<?php esc_attr_e('Save Color', 'ALSP'); ?>" />
</div>