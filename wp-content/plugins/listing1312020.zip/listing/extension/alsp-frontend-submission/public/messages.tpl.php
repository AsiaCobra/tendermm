<?php
	echo do_shortcode('[di-frontend-pm]');
?>